﻿import os
import sys
import time
import requests
import pyfiglet
from datetime import datetime, timedelta
from web3 import Web3
from eth_account import Account
from eth_account.messages import encode_defunct
from colorama import init, Fore, Style

init(autoreset=False)

AUTH_MESSAGE = "X1 Testnet Auth"
SIGNIN_URL = "https://tapi.kod.af/signin"
ME_URL = "https://tapi.kod.af/me"
QUESTS_URL = "https://tapi.kod.af/quests"
FAUCET_URL = "https://nft-api.x1.one/testnet/faucet"
RPC_URL = "https://maculatus-rpc.x1eco.com"
CHAIN_ID = 10778

BOLD = "\033[1m"
GREEN = "\033[32m"
RED = "\033[31m"
YELLOW = "\033[33m"
RESET = "\033[0m"

UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36 Edg/143.0.0.0"

HEADERS_BASE = {
    "accept": "*/*",
    "cache-control": "no-cache",
    "pragma": "no-cache",
    "origin": "https://testnet.x1ecochain.com",
    "referer": "https://testnet.x1ecochain.com/",
    "sec-ch-ua": "\"Microsoft Edge\";v=\"143\", \"Chromium\";v=\"143\", \"Not A(Brand\";v=\"24\"",
    "sec-ch-ua-mobile": "?0",
    "sec-ch-ua-platform": "\"Windows\"",
    "sec-fetch-dest": "empty",
    "sec-fetch-mode": "cors",
    "sec-fetch-site": "cross-site",
    "user-agent": UA
}


def log_green(text):
    print(f"{BOLD}{GREEN}{text}{RESET}")


def log_yellow(text):
    print(f"{BOLD}{YELLOW}{text}{RESET}")


def log_red(text):
    print(f"{BOLD}{RED}{text}{RESET}")


def banner():
    os.system("cls" if os.name == "nt" else "clear")
    ascii_art = pyfiglet.figlet_format("Yuurisandesu", font="standard")
    print(Fore.CYAN + Style.BRIGHT + ascii_art + RESET)
    print(Fore.MAGENTA + Style.BRIGHT + "Welcome to Yuuri, X1 Ecochain Daily Runner" + RESET)
    log_green("Ready to hack the world?")
    print(f"{YELLOW}{BOLD}Current time {datetime.now().strftime('%d %m %Y %H:%M:%S')}{RESET}\n")


def set_title():
    sys.stdout.write("\x1b]2;X1 Ecochain Daily by : 佐賀県産 (YUURI)\x1b\\")
    sys.stdout.flush()


def build_headers(auth_token=None, json_content=False):
    headers = dict(HEADERS_BASE)
    if json_content:
        headers["content-type"] = "application/json"
    if auth_token:
        headers["authorization"] = auth_token
    return headers


def load_private_keys_from_env():
    path = ".env"
    keys = []
    if not os.path.exists(path):
        log_red("Environment file not found in current directory")
        return keys
    try:
        with open(path, "r") as file:
            for line in file:
                stripped = line.strip()
                if not stripped:
                    continue
                if stripped.startswith("PRIVATEKEY_") and "=" in stripped:
                    name, value = stripped.split("=", 1)
                    value = value.strip()
                    if value:
                        keys.append(value)
    except Exception:
        log_red("Environment file read error")
        return []
    if not keys:
        log_red("No private key entry detected in environment file")
    else:
        log_green(f"Private key entry count detected {len(keys)}")
    return keys


def sign_auth_message(private_key):
    try:
        message = encode_defunct(text=AUTH_MESSAGE)
        signed = Account.sign_message(message, private_key=private_key)
        signature_raw = signed.signature.hex()
        if signature_raw.startswith("0x") or signature_raw.startswith("0X"):
            return signature_raw
        return "0x" + signature_raw
    except Exception:
        log_red("Signature creation process failed")
        return None


def authenticate(private_key):
    log_green("Authentication process started")
    signature = sign_auth_message(private_key)
    if not signature:
        log_red("Signature value is empty")
        return None
    payload = {"signature": signature}
    headers = build_headers(json_content=True)
    try:
        response = requests.post(SIGNIN_URL, json=payload, headers=headers, timeout=30)
    except Exception:
        log_red("Authentication request error")
        return None
    if response.status_code == 429:
        log_yellow("Authentication request is currently rate limited by remote service")
        return {"token": None, "user": None, "rate_limited": True}
    if response.status_code != 200:
        log_red(f"Authentication request failed with status code {response.status_code}")
        return None
    try:
        data = response.json()
    except Exception:
        log_red("Authentication response parse error")
        return None
    token = data.get("token")
    user = data.get("user")
    if not token:
        log_red("Authentication response did not contain token")
        return None
    log_green("Authentication request succeeded")
    return {"token": token, "user": user, "rate_limited": False}


def fetch_account_profile(token):
    headers = build_headers(auth_token=token, json_content=False)
    try:
        response = requests.get(ME_URL, headers=headers, timeout=30)
    except Exception:
        log_red("Account profile request error")
        return None
    if response.status_code != 200:
        log_red(f"Account profile request failed with status code {response.status_code}")
        return None
    try:
        data = response.json()
    except Exception:
        log_red("Account profile response parse error")
        return None
    return data


def request_faucet(address):
    params = {"address": address}
    headers = build_headers(auth_token=None, json_content=False)
    try:
        response = requests.get(FAUCET_URL, params=params, headers=headers, timeout=30)
    except Exception:
        log_red("Faucet request error")
        return False
    if response.status_code != 200:
        log_red(f"Faucet request failed with status code {response.status_code}")
        return False
    log_green("Faucet request succeeded")
    return True


def wait_for_balance(web3, address, required_wei, timeout_seconds=300, check_interval=8):
    log_green("Balance monitoring process started")
    start_time = time.time()
    checksum = Web3.to_checksum_address(address)
    while time.time() - start_time < timeout_seconds:
        try:
            balance = web3.eth.get_balance(checksum)
        except Exception:
            log_yellow("Balance query temporary error")
            time.sleep(check_interval)
            continue
        if balance >= required_wei:
            log_green(f"Wallet balance detected {balance}")
            return balance
        log_yellow("Wallet balance is still below required threshold")
        time.sleep(check_interval)
    log_red("Wallet did not reach required balance in expected period")
    return None


def send_random_transfer(web3, private_key, from_address):
    target_account = Account.create()
    target_address = Web3.to_checksum_address(target_account.address)
    log_green("Onchain transfer preparation to random address started")
    checksum_from = Web3.to_checksum_address(from_address)
    try:
        balance = web3.eth.get_balance(checksum_from)
    except Exception:
        log_red("Balance query error for transfer source")
        return False, None
    transfer_amount = 100000000000000000
    try:
        gas_price = web3.eth.gas_price
    except Exception:
        log_red("Gas price query error")
        return False, None
    gas_limit = 21000
    fee = gas_price * gas_limit
    total_required = transfer_amount + fee
    if balance <= total_required:
        log_yellow("Wallet balance is lower than required amount for planned transfer")
        return False, None
    try:
        nonce = web3.eth.get_transaction_count(checksum_from)
    except Exception:
        log_red("Nonce query error")
        return False, None
    tx = {
        "chainId": CHAIN_ID,
        "nonce": nonce,
        "to": target_address,
        "value": transfer_amount,
        "gas": gas_limit,
        "gasPrice": gas_price
    }
    try:
        signed = web3.eth.account.sign_transaction(tx, private_key=private_key)
        tx_hash = web3.eth.send_raw_transaction(signed.raw_transaction)
        log_green(f"Onchain transfer submitted to random address {target_address}")
        log_green(f"Transfer transaction hash value {tx_hash.hex()}")
        return True, tx_hash.hex()
    except Exception:
        log_red("Onchain transfer execution error")
        return False, None


def fetch_quests(token):
    headers = build_headers(auth_token=token, json_content=False)
    try:
        response = requests.get(QUESTS_URL, headers=headers, timeout=30)
    except Exception:
        log_red("Quest list request error")
        return None
    if response.status_code != 200:
        log_red(f"Quest list request failed with status code {response.status_code}")
        return None
    try:
        data = response.json()
    except Exception:
        log_red("Quest list response parse error")
        return None
    return data


def claim_quest(token, quest_id, quest_title):
    headers = build_headers(auth_token=token, json_content=True)
    params = {"quest_id": quest_id}
    try:
        response = requests.post(QUESTS_URL, params=params, headers=headers, data="", timeout=30)
    except Exception:
        log_red(f"Quest claim request error for quest title {quest_title}")
        return False
    if response.status_code != 200:
        log_yellow(f"Quest claim request failed for quest title {quest_title}")
        return False
    log_green(f"Quest claim request succeeded for quest title {quest_title}")
    return True


def process_wallet(web3, private_key, index_number):
    log_green(f"Wallet session started for index {index_number}")
    account = Account.from_key(private_key)
    address = Web3.to_checksum_address(account.address)
    log_green(f"Wallet address value {address}")
    auth_data = authenticate(private_key)
    token = None
    rate_limited = False
    if not auth_data:
        log_red("Wallet authentication failed so faucet and quest actions will not be executed")
    else:
        if auth_data.get("rate_limited"):
            rate_limited = True
            log_yellow("Wallet session will not execute faucet and quest because authentication is rate limited at this time")
        else:
            token = auth_data["token"]
    if token and not rate_limited:
        profile = fetch_account_profile(token)
        if profile:
            profile_address = profile.get("address")
            points = profile.get("points")
            rank = profile.get("rank")
            if profile_address:
                log_green(f"Account profile address value {profile_address}")
            if points is not None:
                log_green(f"Account profile point value {points}")
            if rank is not None:
                log_green(f"Account profile rank value {rank}")
        faucet_ok = request_faucet(address)
        if not faucet_ok:
            log_red("Faucet claim process did not succeed")
        else:
            try:
                current_gas_price = web3.eth.gas_price
            except Exception:
                log_red("Gas price query error during balance preparation")
                current_gas_price = None
            if current_gas_price is not None:
                required_balance = 100000000000000000 + 21000 * current_gas_price
                balance = wait_for_balance(web3, address, required_balance)
                if not balance:
                    log_red("Wallet balance did not reach transfer requirement after faucet claim")
    transfer_ok, tx_hash = send_random_transfer(web3, private_key, address)
    if not transfer_ok:
        log_red("Onchain transfer execution did not succeed for random transfer quest")
    if token and not rate_limited:
        quests = fetch_quests(token)
        if not quests:
            log_red("Quest list retrieval did not succeed")
        else:
            target_titles = ["Daily Login", "Claim Faucet", "Send X1T"]
            quest_map = {}
            for quest in quests:
                title = quest.get("title")
                quest_id = quest.get("id")
                if title in target_titles and quest_id:
                    quest_map[title] = quest_id
            for title in target_titles:
                quest_id = quest_map.get(title)
                if not quest_id:
                    log_yellow(f"Quest entry not available for quest title {title}")
                    continue
                claim_quest(token, quest_id, title)
    log_green("Wallet session completed for current index")


def compute_next_run():
    now = datetime.now()
    target_time = now.replace(hour=8, minute=1, second=0, microsecond=0)
    if now >= target_time:
        target_time = target_time + timedelta(days=1)
    return target_time


def countdown_until(target_time):
    while True:
        now = datetime.now()
        remaining = target_time - now
        seconds = int(remaining.total_seconds())
        if seconds <= 0:
            sys.stdout.write("\r" + " " * 100 + "\r")
            sys.stdout.flush()
            break
        hours = seconds // 3600
        minutes = (seconds % 3600) // 60
        secs = seconds % 60
        message = f"Countdown to next execution {hours} hours {minutes} minutes {secs} seconds remaining"
        sys.stdout.write("\r" + BOLD + YELLOW + message + RESET)
        sys.stdout.flush()
        time.sleep(1)
    print()


def main():
    set_title()
    web3 = Web3(Web3.HTTPProvider(RPC_URL))
    if not web3.is_connected():
        banner()
        log_red("Connection to network failed")
        return
    while True:
        banner()
        log_green("Daily execution cycle started")
        private_keys = load_private_keys_from_env()
        if not private_keys:
            log_red("No wallet configuration available for execution")
            return
        for idx, pk in enumerate(private_keys, start=1):
            normalized_pk = pk.strip()
            if not normalized_pk:
                continue
            if not (normalized_pk.startswith("0x") or normalized_pk.startswith("0X")):
                normalized_pk = "0x" + normalized_pk
            process_wallet(web3, normalized_pk, idx)
        log_green("Daily execution cycle completed for all configured wallets")
        next_run = compute_next_run()
        log_green(f"Next execution scheduled at {next_run.strftime('%d %m %Y %H:%M:%S')}")
        countdown_until(next_run)


if __name__ == "__main__":
    main()
