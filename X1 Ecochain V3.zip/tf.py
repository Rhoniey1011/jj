import json
import os
import sys
import asyncio
import aiohttp
import pyfiglet
from datetime import datetime
from web3 import Web3
from eth_account import Account
from colorama import init, Fore, Style

init(autoreset=False)

BASE_DIR = os.path.abspath(os.getcwd())
RPC_URL = "https://maculatus-rpc.x1eco.com"
CHAIN_ID = 10778
MAIN_WALLET = "0xab3f670120987d2592e98476c8a3b304c65956bc"

BOLD = "\033[1m"
GREEN = "\033[32m"
RED = "\033[31m"
YELLOW = "\033[33m"
RESET = "\033[0m"


def LG(message):
    print(f"{BOLD}{GREEN}{message}{RESET}")


def log_info(message):
    print(f"{BOLD}{GREEN}{message}{RESET}")


def log_warning(message):
    print(f"{BOLD}{YELLOW}{message}{RESET}")


def log_error(message):
    print(f"{BOLD}{RED}{message}{RESET}")


def banner():
    os.system("cls" if os.name == "nt" else "clear")
    ascii_art = pyfiglet.figlet_format("Yuurisandesu", font="standard")
    print(Fore.CYAN + Style.BRIGHT + ascii_art + RESET)
    print(Fore.MAGENTA + Style.BRIGHT + "Welcome to Yuuri X1 Ecochain Auto Sender" + RESET)
    LG("Ready to hack the world?")
    print(f"{YELLOW}{BOLD}Current time {datetime.now().strftime('%d %m %Y %H:%M:%S')}{RESET}\n")


def set_title():
    sys.stdout.write("\x1b]2;X1 Ecochain Auto Sender by : 佐賀県産 (YUURI)\x1b\\")
    sys.stdout.flush()


def find_wallet_files():
    wallet_files = []
    for root, dirs, files in os.walk(BASE_DIR):
        for name in files:
            if name == "wallets.json":
                full_path = os.path.join(root, name)
                wallet_files.append(full_path)
    return wallet_files


def load_wallets_from_file(path):
    try:
        with open(path, "r") as file:
            data = json.load(file)
    except Exception:
        log_warning(f"Wallet file read error for path {path}")
        return []
    if not isinstance(data, list):
        log_warning(f"Wallet file format not list for path {path}")
        return []
    valid_entries = []
    for entry in data:
        if not isinstance(entry, dict):
            continue
        address = entry.get("address")
        private_key = entry.get("pk")
        if not address or not private_key:
            continue
        valid_entries.append((address, private_key))
    if not valid_entries:
        log_warning(f"Wallet file has no valid entries for path {path}")
    else:
        log_info(f"Wallet file loaded with valid entries for path {path}")
    return valid_entries


def normalize_private_key(private_key):
    if private_key.startswith("0x") or private_key.startswith("0X"):
        return private_key
    return "0x" + private_key


def normalize_address(address):
    try:
        return Web3.to_checksum_address(address)
    except Exception:
        return None


async def rpc_call(session, method, params):
    payload = {
        "jsonrpc": "2.0",
        "id": 1,
        "method": method,
        "params": params
    }
    try:
        async with session.post(RPC_URL, json=payload) as response:
            try:
                data = await response.json()
            except Exception:
                log_error("RPC response parse error")
                return None
    except Exception:
        log_error("RPC request error")
        return None
    if isinstance(data, dict) and data.get("error"):
        log_error(f"RPC call error for method name {method}")
        return None
    return data.get("result")


async def send_all_from_wallet(session, from_address, private_key):
    from_addr = normalize_address(from_address)
    if not from_addr:
        log_error(f"Wallet address value is not valid {from_address}")
        return False, None
    main_addr = normalize_address(MAIN_WALLET)
    if not main_addr:
        log_error("Main wallet address value is not valid")
        return False, None
    pk = normalize_private_key(private_key)
    balance_hex = await rpc_call(session, "eth_getBalance", [from_addr, "latest"])
    if not balance_hex:
        log_error(f"Balance query error for address {from_addr}")
        return False, None
    balance = int(balance_hex, 16)
    if balance <= 0:
        log_warning(f"Wallet balance is zero for address {from_addr}")
        return False, None
    gas_price_hex = await rpc_call(session, "eth_gasPrice", [])
    if not gas_price_hex:
        log_error("Gas price query error")
        return False, None
    gas_price = int(gas_price_hex, 16)
    gas_limit = 21000
    fee = gas_price * gas_limit
    if balance <= fee:
        log_warning(f"Wallet balance is lower than required fee for address {from_addr}")
        return False, None
    value = balance - fee
    nonce_hex = await rpc_call(session, "eth_getTransactionCount", [from_addr, "pending"])
    if not nonce_hex:
        log_error("Nonce query error")
        return False, None
    nonce = int(nonce_hex, 16)
    transaction = {
        "chainId": CHAIN_ID,
        "nonce": nonce,
        "to": main_addr,
        "value": value,
        "gas": gas_limit,
        "gasPrice": gas_price
    }
    try:
        signed = Account.sign_transaction(transaction, private_key=pk)
        raw_bytes = signed.raw_transaction
        raw_hex = raw_bytes.hex()
        if not raw_hex.startswith("0x"):
            raw_hex = "0x" + raw_hex
    except Exception:
        log_error(f"Transaction sign error for address {from_addr}")
        return False, None
    tx_hash = await rpc_call(session, "eth_sendRawTransaction", [raw_hex])
    if not tx_hash:
        log_error(f"Transfer send error for address {from_addr}")
        return False, None
    log_info(f"Transfer transaction sent from {from_addr} to {main_addr}")
    log_info(f"Transaction hash value {tx_hash}")
    return True, tx_hash


try:
    import msvcrt

    def read_key():
        while True:
            ch = msvcrt.getch()
            if ch in (b"\r", b"\n"):
                return "ENTER"
            if ch in (b"\x00", b"\xe0"):
                ch2 = msvcrt.getch()
                if ch2 == b"H":
                    return "UP"
                if ch2 == b"P":
                    return "DOWN"
                continue
            try:
                return ch.decode("utf-8", errors="ignore")
            except Exception:
                continue

except ImportError:
    import termios
    import tty

    def read_key():
        fd = sys.stdin.fileno()
        old_settings = termios.tcgetattr(fd)
        try:
            tty.setraw(fd)
            ch1 = sys.stdin.read(1)
            if ch1 == "\x1b":
                ch2 = sys.stdin.read(1)
                if ch2 == "[":
                    ch3 = sys.stdin.read(1)
                    if ch3 == "A":
                        return "UP"
                    if ch3 == "B":
                        return "DOWN"
                return None
            if ch1 == "\r" or ch1 == "\n":
                return "ENTER"
            return ch1
        finally:
            termios.tcsetattr(fd, termios.TCSADRAIN, old_settings)


def select_wallet_file_menu(descriptions, file_count):
    index = 0
    while True:
        os.system("cls" if os.name == "nt" else "clear")
        banner()
        log_info(f"Detected wallet file count {file_count}")
        print()
        for i, text in enumerate(descriptions):
            if i == index:
                line = f"{BOLD}{GREEN}> {text}{RESET}"
            else:
                line = f"  {text}"
            print(line)
        print()
        print(f"{YELLOW}{BOLD}Use arrow up and arrow down then press enter to confirm selection{RESET}")
        key = read_key()
        if key == "UP":
            index = (index - 1) % len(descriptions)
        elif key == "DOWN":
            index = (index + 1) % len(descriptions)
        elif key == "ENTER":
            return index


async def process_wallets_for_group(session, label, entries, concurrency_limit):
    log_info(f"Auto send process started for group {label}")
    semaphore = asyncio.Semaphore(concurrency_limit)
    tasks = []

    async def worker(addr, pk):
        async with semaphore:
            log_info(f"Transfer execution started for wallet {addr}")
            success, tx_hash = await send_all_from_wallet(session, addr, pk)
            if success:
                log_info(f"Transfer execution completed for wallet {addr}")
            else:
                log_warning(f"Transfer execution skipped or failed for wallet {addr}")

    for address, private_key in entries:
        tasks.append(asyncio.create_task(worker(address, private_key)))
    if tasks:
        await asyncio.gather(*tasks)
    log_info(f"Auto send process completed for group {label}")


async def run_auto_send(selected_index, groups):
    timeout = aiohttp.ClientTimeout(total=None)
    async with aiohttp.ClientSession(timeout=timeout) as session:
        concurrency_limit = 50
        if selected_index == len(groups):
            combined_entries = []
            for g in groups:
                combined_entries.extend(g["entries"])
            await process_wallets_for_group(session, "all wallet groups", combined_entries, concurrency_limit)
        else:
            group = groups[selected_index]
            await process_wallets_for_group(session, group["label"], group["entries"], concurrency_limit)


def main():
    set_title()
    banner()
    log_info(f"Target base directory path {BASE_DIR}")
    wallet_files = find_wallet_files()
    if not wallet_files:
        log_warning("No wallet file detected in target directory")
        return
    groups = []
    total_wallets = 0
    for path in wallet_files:
        entries = load_wallets_from_file(path)
        count = len(entries)
        total_wallets += count
        rel_path = os.path.relpath(path, BASE_DIR)
        rel_path = rel_path.replace(os.sep, "/")
        label = f"Wallet file {rel_path} wallet count {count}"
        groups.append({
            "path": path,
            "label": label,
            "entries": entries
        })
    log_info(f"Total wallet file detected {len(groups)}")
    log_info(f"Total wallet entry detected {total_wallets}")
    descriptions = [g["label"] for g in groups]
    descriptions.append("Send all wallets from every file")
    selected_index = select_wallet_file_menu(descriptions, len(groups))
    asyncio.run(run_auto_send(selected_index, groups))


if __name__ == "__main__":
    main()
