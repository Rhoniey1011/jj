﻿import json
import os
import sys
import time
import requests
import pyfiglet
from datetime import datetime
from web3 import Web3
from eth_account import Account
from eth_account.messages import encode_defunct
from colorama import init, Fore, Style

init(autoreset=False)

AUTH_MESSAGE = "X1 Testnet Auth"
SIGNIN_URL = "https://tapi.kod.af/signin"
FAUCET_URL = "https://nft-api.x1.one/testnet/faucet"
WALLETS_FILE = "wallets.json"

BOLD = "\033[1m"
GREEN = "\033[32m"
RED = "\033[31m"
YELLOW = "\033[33m"
RESET = "\033[0m"

UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36 Edg/143.0.0.0"

HEADERS_BASE = {
    "accept": "application/json, text/plain, */*",
    "cache-control": "no-cache",
    "pragma": "no-cache",
    "origin": "https://testnet.x1ecochain.com",
    "referer": "https://testnet.x1ecochain.com/",
    "sec-ch-ua": "\"Microsoft Edge\";v=\"143\", \"Chromium\";v=\"143\", \"Not A(Brand\";v=\"24\"",
    "sec-ch-ua-mobile": "?0",
    "sec-ch-ua-platform": "\"Windows\"",
    "sec-fetch-dest": "empty",
    "sec-fetch-mode": "cors",
    "sec-fetch-site": "cross-site",
    "user-agent": UA
}


def LG(message):
    print(f"{BOLD}{GREEN}{message}{RESET}")


def log_info(message):
    print(f"{BOLD}{GREEN}{message}{RESET}")


def log_warning(message):
    print(f"{BOLD}{YELLOW}{message}{RESET}")


def log_error(message):
    print(f"{BOLD}{RED}{message}{RESET}")


def banner():
    os.system("cls" if os.name == "nt" else "clear")
    ascii_art = pyfiglet.figlet_format("Yuurisandesu", font="standard")
    print(Fore.CYAN + Style.BRIGHT + ascii_art + RESET)
    print(Fore.MAGENTA + Style.BRIGHT + "Welcome to Yuuri, X1 Ecochain" + RESET)
    LG("Ready to hack the world")
    print(f"{YELLOW}{BOLD}Current time {datetime.now().strftime('%d-%m-%Y %H:%M:%S')}{RESET}\n")


def set_title():
    sys.stdout.write("\x1b]2;X1 Ecochain by : 佐賀県産 (YUURI)\x1b\\")
    sys.stdout.flush()


def build_headers(auth_token=None, json_content=False):
    headers = dict(HEADERS_BASE)
    if json_content:
        headers["content-type"] = "application/json"
    if auth_token:
        headers["authorization"] = auth_token
    return headers


def create_wallet():
    account = Account.create()
    address = Web3.to_checksum_address(account.address)
    private_key_raw = account.key.hex()
    if private_key_raw.startswith("0x"):
        private_key = private_key_raw
    else:
        private_key = "0x" + private_key_raw
    return address, private_key


def sign_auth_message(private_key):
    try:
        message = encode_defunct(text=AUTH_MESSAGE)
        signed = Account.sign_message(message, private_key=private_key)
        signature_raw = signed.signature.hex()
        if signature_raw.startswith("0x"):
            signature = signature_raw
        else:
            signature = "0x" + signature_raw
        return signature
    except Exception:
        log_error("Signature creation error")
        return None


def authenticate(private_key):
    log_info("Authentication process started")
    signature = sign_auth_message(private_key)
    if not signature:
        log_error("Signature value is empty")
        return None
    payload = {"signature": signature}
    headers = build_headers(json_content=True)
    try:
        response = requests.post(SIGNIN_URL, json=payload, headers=headers, timeout=30)
    except Exception:
        log_error("Authentication request error")
        return None
    if response.status_code != 200:
        log_error(f"Authentication request failed with status code {response.status_code}")
        return None
    try:
        data = response.json()
    except Exception:
        log_error("Authentication response parse error")
        return None
    token = data.get("token")
    if not token:
        log_error("Authentication response has no token")
        return None
    log_info("Authentication request succeeded")
    return token


def request_faucet(address, token):
    params = {"address": address}
    headers = build_headers(auth_token=token, json_content=False)
    try:
        response = requests.get(FAUCET_URL, params=params, headers=headers, timeout=30)
    except Exception:
        log_error("Faucet request error")
        return False
    if response.status_code != 200:
        log_error(f"Faucet request failed with status code {response.status_code}")
        return False
    log_info("Faucet request succeeded")
    return True


def save_wallet(address, private_key):
    data = []
    if os.path.exists(WALLETS_FILE):
        try:
            with open(WALLETS_FILE, "r") as file:
                data = json.load(file)
        except Exception:
            data = []
    entry = {"address": address, "pk": private_key}
    data.append(entry)
    with open(WALLETS_FILE, "w") as file:
        json.dump(data, file, indent=2)


def main():
    set_title()
    banner()
    try:
        raw_count = input(f"{YELLOW}{BOLD}Enter claim count then press enter {RESET}")
        claim_count = int(raw_count.strip())
    except Exception:
        log_error("Claim count input is not valid integer")
        return
    if claim_count <= 0:
        log_warning("Claim count value is zero or negative")
        return
    for index in range(claim_count):
        cycle_number = index + 1
        log_info(f"Claim cycle {cycle_number} started")
        log_info("Wallet creation started")
        address, private_key = create_wallet()
        log_info(f"Wallet created with address {address}")
        token = authenticate(private_key)
        if not token:
            log_error("Authentication process did not return token")
            continue
        faucet_ok = request_faucet(address, token)
        if not faucet_ok:
            log_error("Faucet request did not succeed")
            continue
        save_wallet(address, private_key)
        log_info("Wallet data saved in file")
        log_info(f"Claim cycle {cycle_number} completed")


if __name__ == "__main__":
    main()
